/*
 * Copyright The OpenTelemetry Authors
 * SPDX-License-Identifier: Apache-2.0
 */

package com.example.javaagent;

import java.util.HashMap;
import java.util.Map;

public class ServiceKeyRouteMap {
  private Map<String, String> serviceKeyMap;
  private Map<String, String> apmIdMap;
  private String apmId;
  private static ServiceKeyRouteMap instance = new ServiceKeyRouteMap();

  private ServiceKeyRouteMap() {
    this.serviceKeyMap = new HashMap<>();
    this.apmIdMap = new HashMap<>();
  }

  public static ServiceKeyRouteMap getInstance() {
    return instance;
  }

  public String getServiceKey(String route) {
    return this.serviceKeyMap.get(route);
  }

  public String getApmId(String route) {
    return this.apmIdMap.get(route);
  }

  public String getApmId() {
    return this.apmId;
  }

  public void putServiceKey(String route, String serviceKey) {
    this.serviceKeyMap.putIfAbsent(route, serviceKey);
  }

  public void putApmId(String route, String apmId) {
    this.apmIdMap.putIfAbsent(route, apmId);
    this.apmId = apmId;
  }
}
