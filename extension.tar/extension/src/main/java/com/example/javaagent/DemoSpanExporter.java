/*
 * Copyright The OpenTelemetry Authors
 * SPDX-License-Identifier: Apache-2.0
 */

package com.example.javaagent;

import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collection;
import java.util.Map;

/**
 * See <a
 * href="https://github.com/open-telemetry/opentelemetry-specification/blob/master/specification/trace/sdk.md#span-exporter">
 * OpenTelemetry Specification</a> for more information about {@link SpanExporter}.
 *
 * @see DemoAutoConfigurationCustomizerProvider
 */
public class DemoSpanExporter implements SpanExporter {
  private boolean DEBUG = false;

  @Override
  public CompletableResultCode export(Collection<SpanData> spans) {
    String HEADER_CTX = "\"Header\"";
    String APPLICATION_CTX = "\"Application\"";
    String SERVICE_CTX = "\"Service\"";
    String RESULT_CTX = "\"Result\"";

    for (SpanData span : spans) {
      if (DEBUG)
        System.out.println("DemoSpanExporter::export() BEGIN PROCESSING EXPORT span -> " + span);

      if (DEBUG) {
        if (span.getKind() == SpanKind.INTERNAL) {
          System.out.println(
              "DemoSpanExporter::export() Received span of INTERNAL kind. span.getTraceId(): "
                  + span.getTraceId()
                  + ", span.getAttributes().asMap(): "
                  + span.getAttributes().asMap());
        } else {
          System.out.println(
              "DemoSpanExporter::export() Recevied span.getKind(): "
                  + span.getKind()
                  + ", span.getAttributes().asMap(): "
                  + span.getAttributes().asMap());
        }
      }

      // Determine if this is an inbound or outbound span
      String headerType = (span.getKind() == SpanKind.SERVER) ? "Inbound" : "Outbound";

      // Calculate the elapsed time
      long elapsed = (span.getEndEpochNanos() - span.getStartEpochNanos()) / 1000000L;

      // Get the service key based on the HTTP route if this is a Web API
      // TODO: Handle databases and etc.  We will be able to distinguish outbound calls to a
      //       DB, and set to key to something like "dbname::operation:etc..."
      String key = "";

      // Use the trace id as the correlation id for ELI
      String correlId = span.getTraceId();
      String recId = span.getSpanId();

      // Placeholder variables for call context details.  Will parsed these out of the attributes
      // contained in the span record
      boolean isHttp = false;
      boolean isDB = false;

      String httpMethod = "";
      String httpTarget = "";
      String httpStatusCode = "";
      String callType = "";
      String httpRoute = "";
      String hostName = "";
      String hostPort = "";
      String httpScheme = "";
      String ip = "";
      // String serviceKey = "";

      String sqlTable = "";

      // Parse out call context details from attributes of the span record. Really UGLY POC code
      if (span.getAttributes() != null) {
        Map attrMap = span.getAttributes().asMap();

        if (attrMap != null && attrMap.keySet() != null) {
          // httpTarget = attrMap.get("http.target").toString();
          for (Object key_ : attrMap.keySet()) {
            if (key_ != null) {
              Object value = attrMap.get(key_);

              //
              // HTTP context
              if (value != null) {
                if (key_.toString().equals("http.status_code")) {
                  httpStatusCode = value.toString();
                  callType = "Rest";
                  isHttp = true;
                } else if (key_.toString().equals("http.target")) {
                  httpTarget = value.toString();
                  isHttp = true;
                } else if (key_.toString().equals("http.method")) {
                  httpMethod = value.toString();
                  isHttp = true;
                } else if (key_.toString().equals("http.scheme")) {
                  httpScheme = value.toString();
                  isHttp = true;
                } else if (key_.toString().equals("net.host.name")) {
                  hostName = value.toString();
                  isHttp = true;
                } else if (key_.toString().equals("http.route")) {
                  httpRoute = value.toString();
                  isHttp = true;
                } else if (key_.toString().equals("net.host.port")) {
                  hostPort = ":" + value.toString();
                  isHttp = true;
                } else if (key_.toString().equals("net.sock.peer.addr")) {
                  ip = ":" + value.toString();
                  isHttp = true;
                } else if (key_.toString().equals("db.sql.table")) {
                  sqlTable = value.toString();
                  isDB = true;
                }
              }
            }
          }
        }
      }

      // Compute the ELI StartTS timestamp field
      LocalDateTime ldt =
          Instant.ofEpochMilli(span.getStartEpochNanos() / 1000000L)
              .atZone(ZoneId.systemDefault())
              .toLocalDateTime();
      String startTS = ldt.toString();

      key = ServiceKeyRouteMap.getInstance().getServiceKey(httpTarget);
      String apmId = ServiceKeyRouteMap.getInstance().getApmId(httpTarget);

      //
      // Write out the ELI event to stdout console - really UGLY POC version :)
      // This isn't actually compliant JSON, but has the structure of an ELI JSON event
      //

      if (isHttp) {
        System.out.printf(
            "<<AUTO INSTRUMENTED ELI LOGGING>> {%s: {AppId: %s, Type: %s, StartTS: %s, RecId: %s}, %s: {APP_ReqId: %s, Host: %s}, %s: {Key: %s, CallType: %s, URL: %s, Operation: %s}, %s:{Elapsed: %d, ErrorCode: %s}} \n",
            HEADER_CTX,
            apmId,
            headerType,
            startTS,
            recId,
            APPLICATION_CTX,
            correlId,
            ip,
            SERVICE_CTX,
            key,
            callType,
            httpScheme + "://" + hostName + hostPort + httpTarget,
            httpMethod,
            RESULT_CTX,
            elapsed,
            httpStatusCode);
      } else {
        System.out.printf(
            "<<AUTO INSTRUMENTED ELI LOGGING>> {%s: {AppId: %s, Type: %s, StartTS: %s, RecId: %s}, %s: {APP_ReqId: %s, Host: %s}, %s: {Key: %s, CallType: %s, URL: %s, Operation: %s}, %s:{Elapsed: %d, ErrorCode: %s}} \n",
            HEADER_CTX,
            apmId,
            headerType,
            startTS,
            recId,
            APPLICATION_CTX,
            correlId,
            ip,
            SERVICE_CTX,
            key,
            callType,
            httpScheme + "://" + hostName + hostPort + httpTarget,
            httpMethod,
            RESULT_CTX,
            elapsed,
            httpStatusCode);
      }

      if (DEBUG)
        System.out.println("DemoSpanExporter::export() END PROCESSING EXPORT span -> " + span);
    }

    return CompletableResultCode.ofSuccess();
  }

  @Override
  public CompletableResultCode flush() {
    return CompletableResultCode.ofSuccess();
  }

  @Override
  public CompletableResultCode shutdown() {
    return CompletableResultCode.ofSuccess();
  }
}
